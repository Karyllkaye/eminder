package com.example.eminderapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

public class LogIn extends AppCompatActivity {

    private EditText passEdit;
    private CheckBox mCheckBox;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        passEdit =findViewById(R.id.enterpass);
        mCheckBox = findViewById(R.id.showpass);

        passEdit.setTransformationMethod(new PasswordTransformationMethod());
        mCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    passEdit.setTransformationMethod(null);
                } else {
                    passEdit.setTransformationMethod(new PasswordTransformationMethod());
                }
                passEdit.setSelection(passEdit.getText().length());

            }
        });
    }
}