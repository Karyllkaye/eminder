package com.example.eminderapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class log_sign_in extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_sign_in);
    }
}